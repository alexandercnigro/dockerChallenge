# Alex Nigro - 2/18/2019

# for challenge 2

curl 34.73.127.62:3000